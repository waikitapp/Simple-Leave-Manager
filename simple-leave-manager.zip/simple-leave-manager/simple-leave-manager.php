<?php
/*
Plugin Name: Simple Leave Manager
Description: Basic employee leave request plugin (V1)
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit; 
}

//  Activate plugin
register_activation_hook(__FILE__, 'slm_create_leave_table');

function slm_create_leave_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'leave_requests';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        employee_name VARCHAR(100) NOT NULL,
        leave_date_from DATE NOT NULL,
        leave_date_to DATE NOT NULL,
        reason TEXT,
        status VARCHAR(20) DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Display Leave Form
add_shortcode('leave_form', 'slm_leave_form_shortcode');

function slm_leave_form_shortcode() {
    ob_start();
    ?>

    <form method="post">
        <p>
            <label>Name:</label><br>
            <input type="text" name="employee_name" required>
        </p>

        <p>
            <label>From Date:</label><br>
            <input type="date" name="leave_date_from" required>
        </p>

        <p>
            <label>To Date:</label><br>
            <input type="date" name="leave_date_to" required>
        </p>

        <p>
            <label>Reason:</label><br>
            <textarea name="reason"></textarea>
        </p>

        <p>
            <input type="submit" name="submit_leave" value="Submit Leave">
        </p>
    </form>

    <?php
    return ob_get_clean();
}

// Form Submission
add_action('init', 'slm_handle_form_submission');

function slm_handle_form_submission() {
    if (isset($_POST['submit_leave'])) {

        global $wpdb;

        $table_name = $wpdb->prefix . 'leave_requests';

        $employee_name = sanitize_text_field($_POST['employee_name']);
        $leave_date_from = sanitize_text_field($_POST['leave_date_from']);
        $leave_date_to = sanitize_text_field($_POST['leave_date_to']);
        $reason = sanitize_textarea_field($_POST['reason']);

        $wpdb->insert(
            $table_name,
            [
                'employee_name' => $employee_name,
                'leave_date_from' => $leave_date_from,
                'leave_date_to' => $leave_date_to,
                'reason' => $reason,
                'status' => 'pending',
            ]
        );
		
		echo "Leave request submitted!";
    }
}

// Admin Menu
add_action('admin_menu', 'slm_add_admin_menu');

function slm_add_admin_menu() {
    add_menu_page(
        'Leave Requests',
        'Leave Requests',
        'manage_options',
        'leave-requests',
        'slm_leave_requests_page',
        'dashicons-list-view',
        20
    );
}

function slm_leave_requests_page() {
    global $wpdb;
	
	if (isset($_GET['message']) && $_GET['message'] == 'success') {
       echo '<div style="padding:10px; background:#d4edda; margin-bottom:10px;">
            Action completed successfully!
          </div>';
   }

    $table_name = $wpdb->prefix . 'leave_requests';

    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");

    ?>

    <div class="wrap">
        <h1>Leave Requests</h1>

        <table border="1" cellpadding="10" cellspacing="0">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>From</th>
                <th>To</th>
                <th>Reason</th>
                <th>Status</th>
				<th>Action</th>
            </tr>

            <?php if (!empty($results)) : ?>
                <?php foreach ($results as $row) : ?>
                    <tr>
                        <td><?php echo $row->id; ?></td>
                        <td><?php echo esc_html($row->employee_name); ?></td>
                        <td><?php echo $row->leave_date_from; ?></td>
                        <td><?php echo $row->leave_date_to; ?></td>
                        <td><?php echo esc_html($row->reason); ?></td>
                        <td><?php echo ucfirst($row->status); ?></td>
						<td>
							<a href="?page=leave-requests&action=approve&id=<?php echo $row->id; ?>">Approve</a> |
							<a href="?page=leave-requests&action=reject&id=<?php echo $row->id; ?>">Reject</a>
						</td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="6">No requests found</td>
                </tr>
            <?php endif; ?>

        </table>
    </div>

    <?php
}

// handle Approve / Reject
add_action('admin_init', 'slm_handle_leave_action');

function slm_handle_leave_action() {
    if (isset($_GET['action']) && isset($_GET['id'])) {

        global $wpdb;

        $table_name = $wpdb->prefix . 'leave_requests';

        $id = intval($_GET['id']);
        $action = $_GET['action'];

        if ($action === 'approve') {
            $wpdb->update(
                $table_name,
                ['status' => 'approved'],
                ['id' => $id]
            );
        }

        if ($action === 'reject') {
            $wpdb->update(
                $table_name,
                ['status' => 'rejected'],
                ['id' => $id]
            );
        }
        
        wp_redirect(admin_url('admin.php?page=leave-requests&message=success'));
        exit;
    }
}
?>